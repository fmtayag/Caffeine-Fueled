Caffeine Fueled
Release version: 1.0.2
Author: zyenapz
E-mail: zyenapz@gmail.com
Website: zyenapz.github.io

Hello, there! I thank you so much for downloading Caffeine Fueled, my entry for the Pygame Community New Years Jam! I hope you enjoy the game!

What is this game?
------------------
Caffeine Fueled is a side-scroller game where you take control of a guy with a coffee-powered jetpack and try to dodge the evil copter kids and other random stuff flying in the sky. The game also features a shop where you can buy cosmetic hats and pets. 

It's my entry for the Pygame Community New Years Jam, which can be found here:
https://itch.io/jam/pygame-community-jam

Controls
--------
W, SPACE, UP 		- Move up
S, SHIFT, DOWN 		- Move down
A, LEFT 			- Move Left
D, RIGHT 			- Move Right

Credits
--------
Programming, art, sound effects by zyenapz
Font: 'Press Start' downloaded from codeman38
Music: 'HappyBeat' downloaded from YouTube and made by Electro Baptist

---------------------
Update 1.0.2
- Fixed a bug where pressing ESC key when game is over won't save the keys
- Hats cost 20 coins now, while pets still cost 30 coins
- Moved the dev info image a bit to the left
- Changed the help screen to briefly explain the gameplay

Update 1.0.1
- Bugfixing regarding it not running on some systems