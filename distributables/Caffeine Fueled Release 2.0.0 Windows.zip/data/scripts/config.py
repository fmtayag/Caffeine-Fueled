# Config.py

WIN_SZ = [768,512]
WIN_CEN = [ WIN_SZ[0] / 2, WIN_SZ[1] / 2]
TILE_SZ = 32