import pygame

class Button(pygame.sprite.Sprite):
    def __init__(self, x, y, text, font_name, color, width, height, thickness):
        super().__init__()
        self.x = x
        self.y = y
        self.text = text.split(" ")
        self.font_name = font_name
        self.color = color
        self.width = width
        self.height = height
        self.thickness = thickness
        self.orig_thickness = self.thickness
        self.state = "HIGHLIGHTED"
        
        # Surface
        self.image = pygame.Surface((self.width, self.height)).convert_alpha()
        self.image.set_colorkey('black')
        self.rect = self.image.get_rect()
        self.rect.center = (self.x, self.y)
        self.img_center = (self.image.get_width() / 2, self.image.get_height() / 2)

        # Font
        self.font_size = self.width // 8
        self.font_object = pygame.font.Font(self.font_name, self.font_size)

    def update(self):
        if self.state == "HIGHLIGHTED":
            self.highlight()
        elif self.state == "UNHIGHLIGHTED":
            self.unhighlight()

    def highlight(self):
        self.refill()
        pygame.draw.rect(self.image, self.color, (0, 0, self.width, self.height), 0)
        self.draw_text()

    def unhighlight(self):
        self.refill()
        pygame.draw.rect(self.image, self.color, (0, 0, self.width, self.height), self.thickness)
        self.draw_text()

    def refill(self):
        self.image.fill('black')
        self.image.set_colorkey('black')

    def draw_text(self):
        y_pos = 1
        for text in self.text:
            self.font_render = self.font_object.render(text, 1, self.color)
            self.fr_rect = self.font_render.get_rect(center=(self.img_center[0], self.img_center[1] * y_pos / 1.5))
            self.image.blit(self.font_render, self.fr_rect)
            y_pos += 1